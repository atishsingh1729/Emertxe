/*
NAME - ATISH SINGH

DATE - 20/1/2023

PROJECT TITLE - INVERTED INDEX

Project Title : Inverted Search

Sample Input : ./ProjectDS.exe file1.txt file2.txt

Sample Output :

Successful in Inserting file file1.txt into the File Linked List
Successful in Inserting file file2.txt into the File Linked List
1. Create Database
2. Display Database
3. Update Database
4. Search
5. Save Database
Enter your Choice: 1
Successfully created database for file1.txt file
Successfully created database for file2.txt file
Do you want to continue (y/n): y
1. Create Database
2. Display Database
3. Update Database
4. Search
5. Save Database
Enter your Choice: 2
[index] [word] filecount file/s : file_name word_count

[0]	[are]	1		file/s:		File : file1.txt	1	

---------------------------------------------
[7]	[hi]	1		file/s:		File : file1.txt	1	
[7]	[hello]	1		file/s:		File : file1.txt	1	
[7]	[how]	1		file/s:		File : file1.txt	1	

---------------------------------------------
[24]	[you]	1		file/s:		File : file1.txt	1	

---------------------------------------------



--------------------------------------------------

*/
#include "inverted_search.h"

int main(int argc , char *argv[])
{
    system("clear");

    Wlist *head[27] = {NULL};

    //validate CLA
    if(argc <= 1)
    {
	printf("Enter the valid no. arguments\n");
	printf("./Slist.exe f1.txt f2.txt ....\n");
	return 0;
    }

    //create list of files 

    //declare file head pointer

    Flist *f_head = NULL;

    //validation of files

    file_validation_n_file_list(&f_head , argv);

    if(f_head == NULL)
    {
	printf("No files are available in the file list\n");
	printf("Hence the process terminated\n");
	return 1;
    }

    //Prompt the user choice 

    int choice;
    char option;
    char word[WORD_SIZE];

    do
    {
        printf("Select your choice among following options:\n1. Create Database\n2. Display Database\n3. Update Database\n4. Search\n5. Save Database\nEnter your Choice: ");
        scanf("%d", &choice);
	
        switch (choice)
        {
        
            //create    
            case 1:
 	            //CREATE DATABASE
			create_database(f_head , head);
	             
                break;
        
            //display            
            case 2:
	            // DISPLAY DATABASE
			display_database(head);
	            break;
            //update        
	        case 3:
	            //UPDATE DATABASE
		        update_database(head , &f_head);

	            break;
            //search        
             case 4:
 	            //SEARCH 
    			printf("Enter the word to search\n");
   			scanf("%s" , word);
    			search(head[tolower(word[0])%97],word);
	            break;

    	    //save database
    	    case 5:   
	            //SAVE DATABSE

    			save_database(head);
	            break;
        
	        default:
	            break;
	}
    printf("Do you want to continue (y/n): ");
	getchar();        
    scanf("%c",&option);
    } while (option == 'Y'|| option == 'y');
    
}
