/*
NAME : ATISH SINGH
DATE : 22/11/2022
DESCRIPTION : 
C PROJECT ON IMAGE STEGNOGRAPHY 
The image Beautiful.bmp is the input image which is encoded with Secret message which is stored in secret.txt using the process called image stegnography by encoding the LSB bit of the image with secret message data. Since the change in LSB bit information renders a change in image which is very miniscule to be observed by human eye.The project also uses a magic string which acts as an authentication key between the encoder and decoder and can be changed accordingly to add a security feature.  
 
SAMPLE EXECUTION : 

Encoding : ./a.out -e beautiful.bmp secret.txt stego.bmp

Beautiful.bmp - Input image to be encoded with secret data
secret.txt - secret file
stego.bmp - output file after encoding
  
Decoding: ./a.out -d stego.bmp default.txt

stego.bmp - Input image to be decoded for secret data
default.txt - Extracted secret data.

*/



#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "decode.h"

int main(int argc,char *argv[])
{
    

//Validating arg count
if(argc >= 3)
 {

    int operation = check_operation_type(argv); 
    
    if(operation == e_encode)
    {
        printf("##Selected Encoding--->\n");

        EncodeInfo encInfo;

        if(read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
           printf("INFO: Read and validate function is succesfully executed\n");

            if(do_encoding(&encInfo) == e_success)
            {
                printf("---Encoding Successful---\n");
            }

            else
            {
                printf("----Encoding failure---\n");

            }
      
        }

        else
        {
           printf("INFO: Read and validate function is failure\n");
           return -1;
        }
    
    
    }
    else if(operation == e_decode)
    {
        printf("##Selected Decoding--->\n");

        DecodeInfo decInfo;

        if(read_and_validate_decode_args(argv, &decInfo) == d_success)
        {
            printf("INFO: Read and validate function is successful\n");

            if(do_decoding(&decInfo) == d_success)
             {
                printf("---Decoding Successful---\n");
             }

             else
             {
                printf("INFO: Decoding is Failure\n");
             }
        }

        else
        {
            printf("INFO: Read and validate function is failure");
            return -1;
        }

    }

    else
    {
        printf("INFO: Operation is invalid\n");
    }
 }

else
{
    printf("ERROR: Input arguments missing");

}

    return 0;
}
