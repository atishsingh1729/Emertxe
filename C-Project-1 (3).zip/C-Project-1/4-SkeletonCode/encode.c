/*
NAME : ATISH SINGH
DATE : 22/11/2022
DESCRIPTION : 
C PROJECT ON IMAGE STEGNOGRAPHY 
The image Beautiful.bmp is the input image which is encoded with Secret message which is stored in secret.txt using the process called image stegnography by encoding the LSB bit of the image with secret message data. Since the change in LSB bit information renders a change in image which is very miniscule to be observed by human eye.The project also uses a magic string which acts as an authentication key between the encoder and decoder and can be changed accordingly to add a security feature.  
 
SAMPLE EXECUTION : 

Encoding : ./a.out -e beautiful.bmp secret.txt stego.bmp

Beautiful.bmp - Input image to be encoded with secret data
secret.txt - secret file
stego.bmp - output file after encoding
  
Decoding: ./a.out -d stego.bmp default.txt

stego.bmp - Input image to be decoded for secret data
default.txt - Extracted secret data.

*/

#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"

/* Function Definitions */

//Check operation type is Encoding or Decoding

OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1], "-e") == 0)
    {
        return e_encode;
    }
   
    else if(strcmp(argv[1], "-d") == 0)
    {
        return e_decode;
    }

    else
    {
        return e_unsupported;
    }

}

//Read and validate input args

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if( strcmp( strstr(argv[2],".") ,".bmp") == 0)
    {
        encInfo -> src_image_fname = argv[2];

    }

    else
    {
        return e_failure;
    }

    if( strcmp( strstr(argv[3],".") ,".txt") == 0)
    {
        encInfo -> secret_fname = argv[3];
    }

    else
    {
       return e_failure;
    }

    if( argv[4] != NULL)
    {
        encInfo -> stego_image_fname = argv[4];
    }
    
    else
    {
        encInfo -> stego_image_fname = "default.bmp";
    }

    return e_success;
}


/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

/*
* Get file size using fseek
* Input  : file pointer of file
* Output : file size is bytes
* Return : unsigned integer
 */
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);

   return ftell(fptr);
}


/*
* check capacity of image file 
* Input  : structure pointer encInfo
* Output : NIL
* Return : e_success or e_failure
 */

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);
    
    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);


    if(encInfo -> image_capacity > ( strlen(MAGIC_STRING)*8 + 32 + (strlen(encInfo -> extn_secret_file)*8) + 32 + (encInfo -> size_secret_file * 8)))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }

}

/*
* Copy header info of the src file to dest file
* Input  : file pointer of input and output files
* Output : header info is copied into a dest file
* Return : e_success
 */


Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char str[54];

    rewind(fptr_src_image);

    fread(str, sizeof(char), 54, fptr_src_image);

    fwrite(str, sizeof(char), 54, fptr_dest_image);

    return e_success;
}

/*
* Encoding Magic String to dest image
* Input  : Magic string and structure pointer 
* Output : magic string encoded to dest image
* Return : e_success
 */

Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    if((encode_data_to_image(magic_string, strlen(magic_string), encInfo -> fptr_src_image, encInfo -> fptr_stego_image, encInfo)) == e_success)
    {
        return e_success;
    }

    else
    {
        return e_failure;
    } 
}

/*
* Subfunction to encode data to image
* Input  : char pointer of data, size ,File pointers for i/o and o/p file, structure pointer 
* Output : data is encoded into the file byte by byte 
* Return : e_success
*/

Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image, EncodeInfo *encInfo)
{
    for(int i = 0; i < size; i++)
    { 
    
        fread(encInfo -> image_data , sizeof(char), 8, fptr_src_image);
       
        encode_byte_to_lsb(data[i], encInfo -> image_data);

        fwrite(encInfo -> image_data, sizeof(char), 8, fptr_stego_image);
        
    }

    return e_success;
}

/*
* Encode a byte of data to LSB side of image data 
* Input  : 1 byte of secret data and image buffer containg 8 bytes of image data 
* Output : a byte is encoded to 8 bytes of image buffer
* Return : e_success
 */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    unsigned int mask = 1 << 7;

    for(int i = 0; i < 8; i++)
    {
      image_buffer[i] = (image_buffer[i] & 0xFE) | ( (data & mask ) >> (7-i));
      
       mask = mask >> 1;

    }

    return e_success;
}

/*
* Encode secret file extention size of 4 bytes into the dest image
* Input  : Size ,File pointer of i/p and o/p files 
* Output : Size data is encoded to the o/p image 
* Return : e_success or e_failure
 */

Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char str[32];

    fread(str, sizeof(char), 32, fptr_src_image);
    
    encode_size_to_lsb(str, size);

   if( fwrite(str, sizeof(char) , 32 , fptr_stego_image) > 0)
    {
     return e_success;
    }
   else
   {
    return e_failure;
   }

}

/*
* Encode size data to LSB
* Input  : char pointer for image buffer , size 
* Output : 4 bytes size data is encoded to the lsb
* Return : e_success
 */

Status encode_size_to_lsb(char *buffer, int size)
{
    int mask = 1 << 31;

    for(int i = 0; i < 32 ; i++)
    {
    buffer[i] = ( buffer[i] & 0xFE) | ( (size & mask) >> (31-i));

    mask = mask >> 1;

    }

    return e_success;
}
/*
* Encode the extension data to dest image
* Input  : char pointer file extention , structure pointer 
* Output : char data is encoded to the output image  
* Return : e_success
*/

Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn, strlen(file_extn), encInfo -> fptr_src_image , encInfo -> fptr_stego_image, encInfo);

    return e_success;
}

/*
* Encode file size using size to LSB function
* Input  : file size, structure pointer 
* Output : size data is encoded to dest image
* Return : e_success
*/

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    
    char str[32];

    fread(str, sizeof(char), 32, encInfo -> fptr_src_image);

    encode_size_to_lsb(str, file_size);

    fwrite(str, sizeof(char), 32, encInfo -> fptr_stego_image);

    return e_success;
}

/*
* Encode Secret file data to dest image
* Input  : structure pointer 
* Output : secret data is encoded to the dest image file
* Return : e_success or e_failure
*/

Status encode_secret_file_data(EncodeInfo *encInfo)
{


    char str[encInfo -> size_secret_file*8];

    char secret_buff[encInfo -> size_secret_file];

    rewind(encInfo->fptr_secret);                    //rewinding the file pointer back to 0th position

    fread(secret_buff, sizeof(char), encInfo -> size_secret_file, encInfo -> fptr_secret);

    fread(str, sizeof(char), encInfo -> size_secret_file*8, encInfo -> fptr_src_image);

    encode_data_to_image(secret_buff, strlen(secret_buff), encInfo -> fptr_src_image , encInfo -> fptr_stego_image, encInfo);

    fwrite(str, sizeof(char), encInfo -> size_secret_file*8, encInfo -> fptr_stego_image);

    return e_success;
}


/*
* Copy remaining image data to the dest image file 
* Input  : File pointers for i/p and o/p files
* Output : remaining image data is copied to the dest image 
* Return : e_success
 */


Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;

    while( fread(&ch, sizeof(char), 1, fptr_src) > 0)
        fwrite(&ch, sizeof(char), 1, fptr_dest);

    return e_success;
}

/*
* Perform Encoding on the image 
* Input  : structure pointer
* Output : image is encoded with all the relevant information
* Return : e_success or e_failure
 */

Status do_encoding(EncodeInfo *encInfo)
{
 
        if (open_files(encInfo) == e_success)
    {   
        printf("INFO: Open files is a success\n");
        if (check_capacity(encInfo) == e_success)
        {
            printf("INFO: Check capacity is a success\n");
            if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
            {
                printf("INFO: Copied bmp header successfully\n");
                if (encode_magic_string(MAGIC_STRING, encInfo) == e_success)
                {
                    printf("INFO: Encoded magic string successfully\n");
                    strcpy(encInfo->extn_secret_file, strstr(encInfo->secret_fname, "."));
                    if (encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                    {
                        printf("INFO: Encoded secret file extn size\n");
                        if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_success)
                        {
                            printf("INFO: Encoded secret file extn\n");
                            if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_success)
                            {
                                printf("INFO: Encoded secret file size\n");
                                if (encode_secret_file_data(encInfo) == e_success)
                                {
                                    printf("INFO: Encoded secret file data\n");
                                    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                                    {
                                        printf("INFO: Copied remaining data\n");
                                    }

                                    else
                                    {
                                        printf("INFO: Failed to copy remaining data\n");
                                        return e_failure;
                                    }

                                }
                                else
                                {
                                    printf("INFO: Failed to encode secret file data\n");
                                    return e_failure;
                                }
                            }
                            else
                            {
                                printf("INFO: Failed to encode secret file size\n");
                                return e_failure;
                            }
                        }
                        else
                        {
                            printf("INFO: Failed to encode secret file extn\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("INFO: Failed to encoded secret file extn size\n");
                        return e_failure;
                    }
                }

                 else
                 {
                    printf("INFO: Failed to encode magic string\n");
                    return e_failure;
                }
            }
            else
            {
                printf("INFO: Failed to copy bmp header\n");
                return e_failure;
            }
        }
        else
        {
            printf("INFO: Check capacity is a failure\n");
            return e_failure;
        }
    }
    else
    {
        printf("INFO: Open files is a failure\n");
        return e_failure;
    }
    return e_success;


}

